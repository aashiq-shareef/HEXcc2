package dao;

import entity.model.Electronics;
import entity.model.Clothing;
import entity.model.Product;
import entity.model.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderProcessor implements IOrderManagementRepository {
	private Connection connection;

    public OrderProcessor(Connection connection) {
        this.connection = connection;
    }
    
    public int createOrder(User user, List<Product> products) throws UserNotFoundException {
        int orderId = -1;

        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Orders (userId, productId) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            for (Product product : products) {
                stmt.setInt(1, user.getUserId());
                stmt.setInt(2, product.getProductId());
                stmt.addBatch();
            }
            int[] rowsAffected = stmt.executeBatch();

            if (rowsAffected.length > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    orderId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to create order", e);
        }

        return orderId;
    }


    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Orders WHERE userId = ? AND orderId = ?")) {

            stmt.setInt(1, userId);
            stmt.setInt(2, orderId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new OrderNotFoundException("Order not found in the database.");
            }

            System.out.println("Order canceled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to cancel order", e);
        }
    }

    public void createProduct(User user, Product product) throws UserNotFoundException {
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Product VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            stmt.setInt(1, product.getProductId());
            stmt.setString(2, product.getProductName());
            stmt.setString(3, product.getDescription());
            stmt.setDouble(4, product.getPrice());
            stmt.setInt(5, product.getQuantityInStock());
            stmt.setString(6, product.getType());
            stmt.setString(7, product instanceof Electronics ? ((Electronics) product).getBrand() : null);
            stmt.setInt(8, product instanceof Electronics ? ((Electronics) product).getWarrantyPeriod() : 0);
            stmt.setString(9, product instanceof Clothing ? ((Clothing) product).getSize() : null);
            stmt.setString(10, product instanceof Clothing ? ((Clothing) product).getColor() : null);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new UserNotFoundException("Failed to insert product into database");
            }
            System.out.println("Product created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to create product", e);
        }
    }

    public void createUser(User user) {
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO User VALUES (?, ?, ?, ?)")) {
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, user.getUsername());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getRole());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new RuntimeException("Failed to insert user into database");
            }
            System.out.println("User created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to create user", e);
        }
    }

    public Product getProductById(int productId) {
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Product WHERE productId = ?")) {
            stmt.setInt(1, productId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int productId1 = rs.getInt("productId");
                    String productName = rs.getString("productName");
                    String description = rs.getString("description");
                    double price = rs.getDouble("price");
                    int quantityInStock = rs.getInt("quantityInStock");
                    String type = rs.getString("type");
                    
                    return new Product(productId1, productName, description, price, quantityInStock, type);
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {

            e.printStackTrace();
            throw new RuntimeException("Failed to get product by ID", e);
        }
    }
    
    public User getUserById(int userId) throws UserNotFoundException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        User user = null;

        try {
            connection = DBUtil.getDBConn();
            String sql = "SELECT * FROM User WHERE userId = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, userId);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("userId");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String role = resultSet.getString("role");
                user = new User(id, username, password, role);
            } else {
                throw new UserNotFoundException("User with ID " + userId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to fetch user from the database.", e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to close resources.", e);
            }
        }
        return user;
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try (Connection conn = DBUtil.getDBConn();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Product")) {

            while (rs.next()) {
                int productId = rs.getInt("productId");
                String productName = rs.getString("productName");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                int quantityInStock = rs.getInt("quantityInStock");
                String type = rs.getString("type");

                Product product = new Product(productId, productName, description, price, quantityInStock, type);
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to retrieve products from the database", e);
        }
        return products;
    }

    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement("SELECT p.* FROM Product p INNER JOIN Orders o ON p.productId = o.productId WHERE o.userId = ?")) {
            stmt.setInt(1, user.getUserId());
            ResultSet rs = stmt.executeQuery();

            List<Product> products = new ArrayList<>();
            while (rs.next()) {
                int productId = rs.getInt("productId");
                String productName = rs.getString("productName");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                int quantityInStock = rs.getInt("quantityInStock");
                String type = rs.getString("type");

                Product product = new Product(productId, productName, description, price, quantityInStock, type);
                products.add(product);
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to retrieve order by user", e);
        }
    }


}

