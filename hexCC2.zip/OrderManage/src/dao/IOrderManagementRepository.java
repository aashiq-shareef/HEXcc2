package dao;

import entity.model.Product;
import entity.model.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;

import java.util.List;
import java.util.Map;

public interface IOrderManagementRepository {
    int createOrder(User user, List<Product> products) throws UserNotFoundException;
    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;
    void createProduct(User user, Product product) throws UserNotFoundException;
    void createUser(User user);
    List<Product> getAllProducts();
    List<Product> getOrderByUser(User user) throws UserNotFoundException;
	Product getProductById(int productId);
	void cancelOrder(Map<Integer, User> userDatabase, Map<Integer, List<Product>> orderDatabase, int userId,
			int orderId) throws UserNotFoundException, OrderNotFoundException;
	void createProduct(Product product);
}

