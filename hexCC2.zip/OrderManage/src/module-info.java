/**
 * 
 */
/**
 * @author aashi
 *
 */
module OrderManage {
	requires java.sql;
}