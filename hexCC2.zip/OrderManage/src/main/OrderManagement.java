package main;

import dao.OrderProcessor;
import entity.model.Product;
import entity.model.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;

import util.DBUtil;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import java.util.ArrayList;


public class OrderManagement {
    public static void main(String[] args) throws UserNotFoundException, OrderNotFoundException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = null;
        try {
            connection = DBUtil.getDBConn();
            if (connection != null) {
                System.out.println("Connected to the database successfully.");
                OrderProcessor orderProcessor = new OrderProcessor(connection);

                boolean running = true;
                while (running) {
                	System.out.println("Menu:");
                    System.out.println("1. createUser");
                    System.out.println("2. createProduct");
                    System.out.println("3. createOrder");
                    System.out.println("4. cancelOrder");
                    System.out.println("5. getAllProducts");
                    System.out.println("6. getOrderByUser");
                    System.out.println("7. exit");
                    System.out.print("Enter choice: ");
                    int choice = scanner.nextInt();
                    scanner.nextLine();

                    switch (choice) {
                        case 1:
                            createUser(scanner, orderProcessor);
                            break;
                        case 2:
                            createProduct(scanner, orderProcessor);
                            break;
                        case 3:
                        	createOrder(scanner, orderProcessor);
                            break;
                        case 4:
                            cancelOrder(scanner, orderProcessor);
                            break;
                        case 5:
                            getAllProducts(orderProcessor);
                            break;
                        case 6:
                            getOrderByUser(scanner, orderProcessor);
                            break;
                        case 7:
                            running = false;
                            System.out.println("Exiting...");
                            break;
                        default:
                            System.out.println("Invalid choice.");
                    }
                }
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    System.err.println("Failed to close the database connection: " + e.getMessage());
                }
            }
            scanner.close();
        }
    }

	private static void createUser(Scanner scanner, OrderProcessor orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter role: ");
        String role = scanner.nextLine();

        User user = new User(userId, username, password, role);
        orderProcessor.createUser(user);
    }

    private static void createProduct(Scanner scanner, OrderProcessor orderProcessor) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter quantity in stock: ");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter type (Electronics/Clothing): ");
        String type = scanner.nextLine();

        Product product = new Product(productId, productName, description, price, quantityInStock, type);
        try {
            orderProcessor.createProduct(null, product);
        } catch (UserNotFoundException e) {
            System.err.println("User not found: " + e.getMessage());
        }
    }
    
    private static void createOrder(Scanner scanner, OrderProcessor orderProcessor) throws SQLException {
        try {
            System.out.print("Enter user ID: ");
            int userId = scanner.nextInt();
            scanner.nextLine();
            User user = orderProcessor.getUserById(userId);

            if (user != null) {
                System.out.print("Enter number of products in the order: ");
                int numOfProducts = scanner.nextInt();
                scanner.nextLine();

                List<Product> products = new ArrayList<>();
                for (int i = 0; i < numOfProducts; i++) {
                    System.out.print("Enter product ID for product " + (i + 1) + ": ");
                    int productId = scanner.nextInt();
                    scanner.nextLine();

                    Product product = orderProcessor.getProductById(productId);
                    if (product != null) {
                        products.add(product);
                    } else {
                        System.out.println("Product with ID " + productId + " not found.");
                    }
                }

                if (!products.isEmpty()) {
                	int orderId = orderProcessor.createOrder(user, products);
                	if (orderId != -1) {
                	    System.out.println("Order created successfully. Your Order ID = " + orderId);}
                }
            } else {
                System.out.println("User with ID " + userId + " not found.");
            }
        } catch (UserNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

	private static void cancelOrder(Scanner scanner, OrderProcessor orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();

        try {
            orderProcessor.cancelOrder(userId, orderId);
        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

	private static void getAllProducts(OrderProcessor orderProcessor) {
	    List<Product> products = orderProcessor.getAllProducts();
	    for (Product product : products) {
	        System.out.println("Product name: " + product.getProductName() + ", Price: " + product.getPrice() + ", Quantity: " + product.getQuantityInStock());
	    }
	}

    private static void getOrderByUser(Scanner scanner, OrderProcessor orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();

        try {
            List<Product> products = orderProcessor.getOrderByUser(new User(userId, "", "", ""));
            for (Product product : products) {
                System.out.println("Product name: " + product.getProductName() + "  --  Price: " + product.getPrice());
            }
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}


